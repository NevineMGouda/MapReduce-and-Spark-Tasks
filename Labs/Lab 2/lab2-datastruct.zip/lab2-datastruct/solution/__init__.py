#   Instructions:
#   - This the ONLY file you are going to submit as a solution
#   - It can not be renamed
#   - It assumes that all references to external data files are loaded into the params file
#   - Do not put ANY REFERENCES to data files in this file
#   - Do not remove/modify the from solution import *

from pprint import pprint

def tupleRecordsToDictRecords(records,labels):
    """
    Converts a list of tuples into a list of dictionaries

    :param records: list of tuples, e.g. [("Mahmoud", 21, "student"), ("Heba", 34, "teacher")]
    :param labels: list of strings, e.g. ["name", "age", "job"]
    :return: a list of dictionaries where the keys of each dictionary are the labels in respective order,
    e.g.[{"name":"Mahmoud", "age":21, "job":"student"},{"name":"Heba", "age":34, "job":"teacher"}]
    """


def keyByIndex(records, i):
    """
    Given a list of tuples [(1,4,5), (3,5,18), (20,1,8), ...], produce a list of (k,v) tuples
    [   (4, (1,4,5)),
        (5,(3,5,18)),
        (1,(20,1,8)),
    ...], where the keys are the respective fields chosen by the index i in each tuple.
    In the above example the key is 1
    """


def keyByKey(records, k):
    """
    Given a list of dictionaries, e.g.
    [
       {"name":"Mahmoud", "age":21, "job":"student"},
       {"name":"Heba", "age":34, "job":"teacher"}
     ],
      produce a list of (k,v) tuples
    [
     ("student",{"name":"Mahmoud", "age":21, "job":"student"}),
     ("teacher", {"name":"Heba", "age":34, "job":"teacher"}
    ]
    where the keys are respective fields chosen by the key k in each dictionary.
    In the above example the key is "job"
    """




def countByKey(records):
    """
    Given a list or tuples, where the 1st element in the tuple is considered a key, returns
    the count of records having the same key.
    e.g: [("a", 3), ("b", 7), ("a", [1,2,4])] should return {"a":2, "b":1}

    """


def groupByKey(records):
    '''
    Given a list or tuples, where the 1st element in the tuple is considered a key, groups
    all elements who have the same key, e.g:
    [("a", 3), ("b", 7), ("a", [1,2,4])]
    should return
    {"a":[3,[1,2,4]], "b":[7]}
    '''

def main():
    print("Running the solution...")
    #put calls to your funcitons to test them here