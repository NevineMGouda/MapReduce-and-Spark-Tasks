
import solution

if __name__ == '__main__':
    solution.main()
